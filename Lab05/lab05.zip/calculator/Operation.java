package calculator;

interface Operation
{
   double evaluate(Bindings bindings);
}
